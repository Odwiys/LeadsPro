require "test_helper"

class UserQuestionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
